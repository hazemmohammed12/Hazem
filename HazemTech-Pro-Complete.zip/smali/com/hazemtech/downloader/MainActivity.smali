.class public Lcom/hazemtech/downloader/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 3
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    const v0, 0x7f030000
    invoke-virtual {p0, v0}, Lcom/hazemtech/downloader/MainActivity;->setContentView(I)V
    return-void
.end method
